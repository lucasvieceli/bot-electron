export default {
    translation: {
        teste: 'oiiiiii {{name}}',
    },
};
