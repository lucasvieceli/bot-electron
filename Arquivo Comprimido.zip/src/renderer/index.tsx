import ReactDOM from 'react-dom';
import { App } from './App';
console.log('ahisudausdh');
ReactDOM.render(<App />, document.getElementById('root'));
