export interface ContainerProps {
  active: boolean
  borderColor: string
}

export interface MenuSideBarItemProps {
  borderColor: string
  href: string
}
