import styled from 'styled-components'

export const Container = styled.div`
  margin-left: 80px;
  display: flex;
  overflow-x: hidden;
  width: 100%;
`
