import { ReactElement } from 'react'

export interface Menu {
  href: string
  Icon: ReactElement
  color: string
}
