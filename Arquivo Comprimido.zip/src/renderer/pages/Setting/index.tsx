import React, { FC } from 'react'
import { Setting as SettingTemplate } from '../../components/templates'

interface SettingProps {}

const Setting: FC<SettingProps> = ({}) => {
  return <SettingTemplate />
}

export default Setting
