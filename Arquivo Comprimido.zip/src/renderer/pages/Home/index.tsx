import React from 'react'
import { DashBoard } from '../../components/templates'

const Home = () => {
  return <DashBoard />
}

export default Home
