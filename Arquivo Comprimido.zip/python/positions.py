# -*- coding: utf-8 -*-    

from functions.positions import positions
import sys




if __name__ == '__main__':
    #data = sys.stdin.readlines()
    #print(data)

    #sys.stdout.flush()
    print('move')
    print('terminoi')
    print(positions(sys.argv[1]))